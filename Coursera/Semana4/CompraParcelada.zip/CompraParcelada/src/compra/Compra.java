package compra;

public class Compra {

	double valorCompra;
	
	Compra(double val){
		this.valorCompra = val;
	}
	
	public double total(){
		return valorCompra;
	}
	
}
